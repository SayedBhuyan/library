<?php

require_once "init.php";

restrictedArea();

get_header(array(
	"class" => "books"
));

$objBook = new Book();
$books = $objBook->getBooks();

$stsSuccess = getStatus("loginSuccess");

view("index", array(
	"books" => $books,
	"stsSuccess" => $stsSuccess
));

get_footer();

?>